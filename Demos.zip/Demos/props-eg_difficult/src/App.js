import React from 'react';
import ReactDOM from 'react-dom';


import Header from './Header';
import Footer from './Footer';
export default class App extends React.Component {
 
	 render() {

		const title="this is from props";
		return(		
		<div>
		<Header title={title}/>
		<Header name={"tit"} title={title}/>
		<Header title={"other name"}/>
		<h1>this is layout example</h1>
		<Footer />
		</div>
			);
		}
}

