import React from 'react';

import ReactDOM from 'react-dom';


import PropsProb from './PropsProb';


ReactDOM.render(<PropsProb appName="Capgemini"/>, document.getElementById('root'));

