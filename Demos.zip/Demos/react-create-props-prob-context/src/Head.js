import React from 'react';

import ReactDOM from 'react-dom';

import Title from './Title';
import ThemeContext from './ThemeContext';


class Head extends React.Component {
  render() {
    return (
	<div>
        <Title />
	</div>
    );
  }
}
export default Head;



