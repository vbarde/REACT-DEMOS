import React from 'react';

import ReactDOM from 'react-dom';

import Head from './Head';
import ThemeContext from './ThemeContext';

// Context lets us pass a value deep into the component tree
// without explicitly threading it through every component.
// Create a context for the current theme (with "light" as the default).


class PropsProb extends React.Component {
  render() {
    return (
      <ThemeContext.Provider value={'green'}>
        <Head />
	//or {this.props.Children}, if in seperate class the provider is defined
      </ThemeContext.Provider>
    )
  }
}
export default PropsProb;







