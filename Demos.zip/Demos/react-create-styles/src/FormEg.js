import React from 'react';

import ReactDOM from 'react-dom';


class FormEg extends React.Component {

  render() {
	const myStyle={
		
		color:'white',
		backgroundColor:'green',
		fontSize:100,
		border:50,
		

	}
	return(
		<div>
			<h1 style={myStyle}>
	     REACT 
			</h1>
		</div>
	);   
  }
}
export default FormEg;


