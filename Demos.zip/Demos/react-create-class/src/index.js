import React from 'react';

import ReactDOM from 'react-dom';

//import './index.css';
class Greeting extends React.Component
{
  render()
  {
    <div>Hello</div>
  }
  
}

// var createReactClass = require('create-react-class');
// console.log(createReactClass);
// var Greeting = createReactClass({
//   render: function() {
//     return <h1>Hello !!!</h1>;
//   }
// });

ReactDOM.render(<Greeting />, document.getElementById('root'));


