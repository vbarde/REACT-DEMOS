var React = require('react');
var ReactDOM = require('react-dom');

class Greeting extends React.Component
{
render() {
	return(
		<div>
		count
		</div>
	);   
  }
}
export default Greeting;


