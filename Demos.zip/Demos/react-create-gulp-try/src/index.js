import React from 'react';

import ReactDOM from 'react-dom';

import Greeting from './GreetingConditionalRendering';
ReactDOM.render(<Greeting />, document.getElementById('root'));


