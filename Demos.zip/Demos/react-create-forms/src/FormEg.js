import React from 'react';
import ReactDOM from 'react-dom';
class FormEg extends React.Component {
	constructor()
	{
		super();
		this.state={
		// value:''
		firstname:"vishal",
		// lastname:"barde"
		friends:[]
	}
	}
	   handleSubmit=(event)=>{
		 event.preventDefault();
		 const friendsArr=this.state.friends.slice();
		 console.log(friendsArr);
		 friendsArr.push(this.state.firstname);
		 this.setState({
			 friends:friendsArr,
			 firstname:''
		 })
		 setTimeout(()=>{
			console.log("All friends:",this.state.friends)
		 },50)
		}
		 handleChange=90
		//  handleChange=(event)=>{
	//  console.log("change happended");
	
// 	 if(event.target.name=="firstname"){
// 	 this.setState({
// 			firstname: event.target.value,
		
// 		});
// 	}
// 	 else{
// 		this.setState({
// 			lastname: event.target.value,
// 		});
// 	}
// }
render() 
 {
	return(
		<div>
			<form onSubmit={this.handleSubmit}>
    <h1>First Name:{this.state.firstname}</h1>
		{/* <h1>Last Name:{this.state.lastname}</h1> */}
    <label>Name:</label>
	   <input type="text" value={this.state.firstname} onChange={this.handleChange}   name="firstname"/>
		 {/* <input type="text" value={this.state.lastname}  onChange={this.handleChange}   name="lastname" /> */}
		 <br/>
     <input type="submit" value="submit"/>
		 </form>
		</div>
   );   
  
}
		 }
		
export default FormEg;
