import React from 'react';

import ReactDOM from 'react-dom';



import data from './data.json';
 
class Parent extends React.Component {
  render() {
    return (
 request('http://localhost:3000/data.json/', function(error, response, body) {
            var result = JSON.parse(body);
}
//console.log(result);
/*        <ul>
        {
          data.map(function(movie){
            return <li>{movie.id} - {movie.title}</li>;
          })
        }
        </ul>
*/    );
  }
}
 
export default Parent;