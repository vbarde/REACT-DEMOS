import React from 'react';
import ReactDOM from 'react-dom';
class FormEg extends React.Component {
	// constructor()
// 	{
// 	// 	super();
// 	// 	this.state={
// 	// 	value:'',
// 	// 	items:[]
// 	// 	}
// 	// }
// 	// handleInputChange=(event)=>{
// 	// console.log('evt',event.target.value);
// 	// 	this.setState({
// 	// 		value: event.target.value
// 	// 	});
// 	// }
// 	// addCity=(event)=>{
// 	// event.preventDefault();//no navigation should happen
// 	// const arr= this.state.items.slice();
// 	// arr.push(this.refs.newItem.value);
// 	// //set state for originaal array
	
// 	// this.setState({
// 	// 	items:arr,
// 	// 	value:''
// 	// });
// 	// }
// 	render(){
//         return(
// // 	<div>
// //             <form id="add-city" onSubmit={this.addCity.bind(this)}>
// //                 <input type="text" required ref="newItem" onChange={this.handleInputChange}/> 
// //                 <input type="submit" value="Add City" />
// //             </form>
// // 		<ul>
// // 	{this.state.items.map((item,index)=> <li key={index}>{item}</li>)}
// // 	</ul>
// // </div>


//     //Custom functions
//     addCity(e){
//         e.preventDefault();
// 	console.log(this.refs.newItem.value);
//        // this.props.onAdd(this.refs.newItem.value);
//     }
// }
constructor(){
	super();
	this.state={
		username:"vishal"
	}
}
handleClick=(event)=>{
	event.preventDefault();
	console.log(this.refs.username.value);
	this.setState({
		username:this.refs.username.value
	})
}
render(){
	return(
<div>
	<label>name:</label>
	<input type="text" ref="username" name="username"/>
	<br/>
	<input type="button" value="Say Hi" onClick={this.handleClick}/>
	<hr/>
	<h2>{this.state.username}</h2>
	</div>
    );
	}
}
export default FormEg;

