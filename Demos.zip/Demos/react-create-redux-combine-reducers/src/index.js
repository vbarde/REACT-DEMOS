import React from 'react';
import ReactDOM from 'react-dom';
import {combineReducers,createStore} from 'redux';
function deptReducer(state=[],action){
switch(action.type){
	case "ADD_ITEM":
	return [...state,action.data]
	case "DELETE_ITEM":
	const newState =state.map((element,index)=>{
		if(index!=action.index){
			return element;
		}
	}
)
}
	return state;
}
function empReducer(state='',action){
	console.log("hekekv",action);
	return state;
}
const allReducers=combineReducers({
department:deptReducer,
employee:empReducer
});
const store=createStore(allReducers,{
department:[{deptName:"Admin"},{deptName:'engineering'}],
employee:'ajay'
},
window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);
const addAction={
	type:'ADD_ITEM',
	payload:{
		 name:"iphone-x"	
		}
	};
const deleteAction={
	type:'DELETE_ITEM',
	index:1

};

store.dispatch(addAction);
store.dispatch(deleteAction);
console.log(store.getState());
const data=<h1>WELCOME</h1>;
ReactDOM.render(data, document.getElementById('root'));











