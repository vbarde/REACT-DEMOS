import React from 'react';

import ReactDOM from 'react-dom';

import Address from './Address';

class Employee extends React.Component {

  render() {
	return(
		<div>
			<Address/>
		</div>
	);   
  }
}
export default Employee;


