import React from 'react';

import ReactDOM from 'react-dom';


class Parent extends React.Component {
	render() 
	{

	return
	(
		<div>
			count:
			{React.Children.count(this.props.children)}
			{this.props.children}
		</div>
	);   
  }
}
export default Parent;



