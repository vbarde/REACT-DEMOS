import React from 'react';

import ReactDOM from 'react-dom';


import ParentComponent from './ParentComponent';



ReactDOM.render(<ParentComponent />, document.getElementById('root'));



