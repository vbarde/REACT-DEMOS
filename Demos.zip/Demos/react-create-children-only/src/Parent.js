import React from 'react';

import ReactDOM from 'react-dom';


class Parent extends React.Component {
  render() {
	return(
		<div>{React.Children.only(this.props.children)}</div>
	);   
  }
}
export default Parent;


