import React from 'react';
import ReactDOM from 'react-dom';
//import App from './App';
import {createStore} from 'redux';
const store=createStore(reducer);
const action={
type:'changeState',
payload:{
	 newState:'New State'	
	}
};
console.log(store.getState());
function reducer(state,action){
if(action.type==='changeState')
{
	return action.payload.newState;
}
console.log(action);
return 'State';
}
store.dispatch(action);
console.log(store.getState());
const data=<h1>hi , hello</h1>;
ReactDOM.render(data
	, document.getElementById('root'));











