import React from 'react';

import ReactDOM from 'react-dom';


// import App from './App';

import {createStore} from 'redux';

const store=createStore(reducer); //call reducer function
console.log(store.getState()); // get state from reducer
console.log(store);          
function reducer(){
return 'State';
}
ReactDOM.render(<div>Hello</div>
	, document.getElementById('root'));


