import React from 'react';

import ReactDOM from 'react-dom';


class Parent extends React.Component {
  render() {
	const childArr = ['a','b','c','d','f','j'];
	React.Children.forEach(childArr, 
	child=>(
            console.log(child)     
        ));
	
	React.Children.forEach(this.props.children, 
	child=>(
            console.log(child)     
        ));
	return(
		<div>
		{this.props.children}
		{childArr.map((child, index)
			=>(<h3>{child}{index}</h3>))}
		</div>
	);   
  }
}
export default Parent;


