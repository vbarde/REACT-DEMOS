import React from 'react';

//import ReactDOM from 'react-dom';



export default class App extends React.Component {


	 render() {
              console.log("this.props");
		return(		
            <div>
				<h1> Hello{this.props}</h1>
				</div>
	);
    }
}
	// <div>
		// <h1>this is props example , {this.props.name}</h1>
// 		// <h2>city : {this.props.city}</h2>
// 		// </div>
// 	);
	
// }

// }
