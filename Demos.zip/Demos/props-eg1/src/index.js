import React from 'react';
import ReactDOM from 'react-dom';


import App from './App'

var props={};
props.firstName="Vishal";
props.lastName="barde";

// ReactDOM.render(<App name='ajay' city="banglore"/>, document.getElementById('root'));

ReactDOM.render(<App {...props}    />, document.getElementById('root'));

