import React from 'react';

import ReactDOM from 'react-dom';


class Title extends React.Component {
  render() {
	return(
		<div>
		<i>title: {this.props.pqr}</i>
		</div>
	);   
  }
}
export default Title;



