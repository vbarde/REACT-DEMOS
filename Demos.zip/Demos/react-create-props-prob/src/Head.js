import React from 'react';

import ReactDOM from 'react-dom';

import Title from './Title';

class Head extends React.Component {
  render() {
	return(
		<div>
			<h1>content of head component</h1>
			<Title pqr={this.props.xyz}/>
		</div>
	);   
  }
}
export default Head;



