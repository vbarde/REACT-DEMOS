import React from 'react';

import ReactDOM from 'react-dom';


class FormEg extends React.Component {
	constructor()
	{
		super();
		this.state={
		value:'',
		items:[]
		}
	}
	handleInputChange=(event)=>{
	console.log('evt',event.target.value);
		this.setState({
			value: event.target.value
		});
	}
	handleSubmit=(event)=>{
	event.preventDefault();//no navigation should happen
	const arr= this.state.items.slice();
	arr.push(this.state.value);
	//set state for originaal array
	
	this.setState({
		items:arr,
		value:''
	});	
	}
  render() {
		console.log('render',this.state);
	return(
		<div>

			<form onSubmit={this.handleSubmit}>
			<label>name : </label>
			<input value={this.state.value} onChange={this.handleInputChange}/> 
			<button type="submit">add</button>
			</form>
			<ul>
			{this.state.items.map((item,index)=> <li key={index}>{item}</li>)}
			</ul>
		</div>
	);   
  }
}
export default FormEg;


