import React from 'react';
import ReactDOM from 'react-dom';

//import './index.css';




class App extends React.Component {
 
	 render() {
   
	// return React.createElement('div',null,'Hello!!!');
	return(
		<div>bonjour</div>
	)
		}
}

ReactDOM.render(
	React.createElement(App,null,null), 
		document.getElementById('root')
);


/*
const e = React.createElement;

ReactDOM.render(
  e('div', null, 'Hello World'),
  document.getElementById('root')
);
*/

