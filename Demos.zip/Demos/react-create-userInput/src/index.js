import React from 'react';

import ReactDOM from 'react-dom';



export const Go = () => {
  const ele = document.getElementById('root');
  ele.innerHTML = 'Move your mouse to see the demo';
  ele.addEventListener('mousemove', function(evt) {
    const { screenX, screenY } = evt;
    ele.innerHTML = '<div>Mouse is at: X: ' +
          screenX + ', Y: ' + screenY +
                    '</div>';
  })
}

ReactDOM.render(<Go/>
	, document.getElementById('root'));



/*task : iterate by passing json data as products - iterate using foreach*/