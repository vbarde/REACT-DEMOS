import React from 'react';

import ReactDOM from 'react-dom';

import GrandChild from './GrandChild'
class Child extends React.Component {

// render() {
// 		return(<span>{this.props.data}</span>);
	
// 	}
// }
// export default Child;
constructor(){
	super();
	console.log("constructor");
}
componentWillMount(...args){console.log("component will mount",args);}
componentDidMount(...args){console.log("componentDidMount",args);}
shouldComponentUpdate(){
	console.log("shouldcomponentUpdate");
	const rnd=Math.random();
	return rnd>0.5;
}
componentWillReceiveProps(...args){("componentWillReceiveProps",args);}
componentWillUpdate(...args){console.log("componentwillupdate",args);}
componentDidUpdate(...args){console.log("componentdidupdate",args);}
componentWillUnmount(...args){console.log("componenetwillmount",args);}

render(){
	return(
		<div>
		<h2>Company Name in child: {this.props.companyName}</h2>
	    <GrandChild  companyName={this.props.companyName}     />
        </div>
	)
}
}

export default Child;






