import React from 'react'
class GrandChild extends React.Component{
    
    render(){
        return(
            <div>
            <h2>Company Name in grand child: {this.props.companyName}</h2>
      
             </div>
        )
    }
    }
    
    export default GrandChild;
