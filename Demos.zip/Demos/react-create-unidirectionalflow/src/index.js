import React from 'react';

import ReactDOM from 'react-dom';


import Parent from './Parent';
import { GrandChild } from './GrandChild';

ReactDOM.render(<Parent/>
	, document.getElementById('root'));


