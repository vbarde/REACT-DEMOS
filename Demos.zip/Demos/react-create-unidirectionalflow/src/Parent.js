import React from 'react';

import ReactDOM from 'react-dom';

import Child from './Child'; 
class Parent extends React.Component {
// 	constructor(){
// 	super();
// 	this.state={ val:''};
// 		}	
// 	updateText(event){

// 		this.setState({val:event.target.value});
// 			}
// 	render(){
// 	     return(
// 		<div>
// 		<h1>React Unidirectional data flow</h1>
// 	<input type="text" onChange= {this.updateText.bind(this)}/>
// 	&nbsp;
// 	<Child data={this.state.val}/>
// 		</div>
// 			);
// 			}
// }
constructor(){
	super();
	this.state={
		companyName:"cap",
		location:""
		
	}
}
handleChange=(event)=>{

	this.setState({
		companyName:event.target.value,
		location:event.target.value
	})
}
render(){
	return (
		<div>
			Company Name in parent:
			<input type="text"  value={this.state.companyName} onChange={this.handleChange}/>
	
		    <hr/>
			<Child companyName={this.state.companyName}/>
           </div>
	)
}
}
export default Parent;


