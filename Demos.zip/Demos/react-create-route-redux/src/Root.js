import React from 'react';

import ReactDOM from 'react-dom';

import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom'
import { Link,Switch } from 'react-router-dom';
import Home from './Home';
import About from './About';
import App from './App';
import configureStore from './configureStore';
import { Provider } from 'react-redux';
const Root = (props) => {
  const store = configureStore();
  
  return (
    <Provider store={store}>
      <App />
    </Provider>
  );
}
export default Root;