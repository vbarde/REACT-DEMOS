import * as types from './types';
const FETCH_NEW_TIME=
{
  type: types.FETCH_NEW_TIME,
}
