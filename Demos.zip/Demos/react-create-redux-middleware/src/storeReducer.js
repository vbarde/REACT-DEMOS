import React from 'react';
import ReactDOM from 'react-dom';

import {createStore,applyMiddleware} from 'redux';
/*
var createReactClass = require('create-react-class');
var Counter = createReactClass({
  getInitialState: function() {
    return {count: 3};
  },
  render: function() {
    return (<b>hi</b>);}
});
*/
const initialState={count:3};
const reducer=(state=initialState,action)=>{
console.log('reducer runs',action);
	switch(action.type)
	{
//value of state will be stored in Object {}, and then state //value can be changed
		case 'Increment':
	return Object.assign({},state,{count:state.count+1});
	// 	default:
	// return state;
	case 'Decrement':
	return Object.assign({},state,{count:state.count-1});
		default:
	return state;
	}
}
const myLogger=(store)=>(next)=>(action)=>{ console.log("Logged Action:",action);
next(action);
}
const store=createStore(reducer,applyMiddleware(myLogger));
store.subscribe(()=>{
console.log("store subscribed 	",store.getState());
});
export default store;
