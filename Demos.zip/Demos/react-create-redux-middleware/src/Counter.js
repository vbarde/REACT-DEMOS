import React from 'react';
import ReactDOM from 'react-dom';


import {connect} from 'react-redux';

function Counter(props)
{
	console.log('in counter props',props);
	return(
	<div>
	<h1>hi i am counter</h1>
	<p>count:{props.count}</p>
	<button onClick={props.onIncrementClick}>increment</button>
	<button onClick={props.onDecrementClick}>decrerment</button>
	</div>
	);
}
/*const mapStateToProps=state=>({
	count:state.count
});
*/
function mapStateToProps(state){
	console.log('state is :',state);
	return {
	count:state.count
	}
}
function mapDispatchToProps(dispatch){
	console.log('dispatch :',dispatch);
	return {
	onIncrementClick:()=>{
	console.log('inc clicked');
	const action={type:'Increment'};
	dispatch(action);	
	},
	onDecrementClick:()=>{
		console.log('dec clicked');
		const action={type:'Decrement'};
		dispatch(action);	
		}
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Counter);

//








