import React from 'react';  
import ReactDOM from 'react-dom';
import Home from './Home';
import About from './About';
import { createStore, combineReducers, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';  // 
import createHistory from 'history/createBrowserHistory';
import { Route } from 'react-router';
import { ConnectedRouter, routerReducer, routerMiddleware, push } from 'react-router-redux'
import { Link,Switch } from 'react-router-dom';

const initialState={count:3};
const history = createHistory()
const middleware = routerMiddleware(history)
const myReducer=(state=initialState,action)=>{
console.log('reducer runs',action);
console.log("state: ",state);
}
const store = createStore(
  myReducer,applyMiddleware(middleware)
)
ReactDOM.render(
  <Provider store={store}>
    <ConnectedRouter history={history}>
	 <Switch>
          <Route path="/about" component={About} />
          <Route exact={true} path="/" component={Home} />
        </Switch>
    </ConnectedRouter>
  </Provider>,
  document.getElementById('root')
)